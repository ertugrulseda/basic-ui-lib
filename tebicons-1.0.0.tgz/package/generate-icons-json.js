const fs = require("fs");
const path = require("path");

const iconsDir = path.join(__dirname, "src", "assets", "icons");

fs.readdir(iconsDir, (err, files) => {
    if (err) {
        console.error("Error reading directory", err);
        return;
    }

    const fileObjects = { light: [] };

    files.forEach((fileName) => {
        const name = path.parse(fileName).name;
        const filePath = path.join(iconsDir, fileName);
        const content = fs.readFileSync(filePath, "utf8");

        const viewBoxMatch = content.match(/viewBox="([^"]*)"/);
        const viewBox = viewBoxMatch ? viewBoxMatch[1] : null;

        const extractedContent = content.match(/d="([^"]*)"/)[1];
        const pathSegments = extractedContent.split(/(?= M)/).filter(Boolean);

        fileObjects[name] = { viewBox, paths: pathSegments }
        fileObjects.light.push(name);
    });

    const outputFile = path.join(__dirname, "src/output.json");
    fs.writeFile(outputFile, JSON.stringify(fileObjects, null, 2), (err) => {
        if (err) {
            console.error("Error writing output file", err);
            return;
        }
        console.log("Output file written successfully", outputFile)
    })
}) 