const path = require("path");
const generateSvgIcons = require('./src/utils/index');

const HtmlWebpackPlugin = require("html-webpack-plugin");
const CopyWebpackPlugin = require("copy-webpack-plugin");

const { BundleAnalyzerPlugin } = require('webpack-bundle-analyzer');

module.exports = {
    entry: path.join(__dirname, 'src', 'index.ts'),
    mode: 'production',
    output: {
        path: path.resolve(__dirname, "build"),
        globalObject: 'this',
        library: {
            name: 'tebicons',
            type: 'umd'
        },
        clean: true,
    },
    resolve: {
        extensions: [".tsx", ".ts", ".js"]
    },
    module: {
        rules: [
            {
              test: /\.?js$/,
              exclude: /node_modules/,
              use: {
                loader: 'babel-loader',
                options: {
                  presets: ['@babel/preset-env', '@babel/preset-react'],
                },
              },
            },
            {
                test: /\.(ts|tsx)$/,
                exclude: /node_modules/,
                use: {
                    loader: "babel-loader",
                    options: {
                        presets: ["@babel/preset-env", "@babel/preset-react"]
                    }
                }
            },
            {
                test: /\.tsx?$/,
                exclude: /node_modules/,
                loader: 'ts-loader',
            },        
        ]
    },
    plugins: [
        new HtmlWebpackPlugin({
            templateContent: generateSvgIcons(),
            filename: "index.html"
        }),
        new CopyWebpackPlugin({
            patterns: [ { from: 'src/output.json', to: 'output.json'} ]
        }),
        new BundleAnalyzerPlugin({
            analyzerMode: 'static',
            reportFilename: 'tebicons-bundle-report.html',
            openAnalyzer: false
        }),
    ],
    resolve: {
        extensions: ['.ts', '.tsx', '.js', '.jsx'],
    },
    externals: {
        react: 'react',
        'react-dom': 'react-dom',
      },
} 