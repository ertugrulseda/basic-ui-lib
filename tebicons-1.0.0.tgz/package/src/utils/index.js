const output = require('../output.json');
const { light, ...icons } = output;

function generateSvgIcons() {
    let svgs = '';

    Object.keys(icons).forEach(name => {
        const { viewBox, paths } = icons[name];
        const svgPath = 
paths.map
(p => `<path d="${p}"/>`).join('');
        const svgElement = `<div id="${name}" style="display: flex; margin: 4px"><svg width="24" height="24" fill="currentColor" viewBox="${viewBox}">${svgPath}</svg></div>`;
        svgs += svgElement;
    })

    return `
        <!DOCTYPE html>
        <html lang="en">
            <head>
            <meta charset="UTF-8"/>
            <meta name content="width=device-width, initial-scale=1.0" />
            </head>
            <body>
                <div id="icon-container" style="display: flex; flex-wrap: wrap;">
                    ${svgs}
                </div>
            </body>
        </html>
    `
}
module.exports = generateSvgIcons; 