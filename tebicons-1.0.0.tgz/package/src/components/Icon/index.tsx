import React, { FC } from "react";

import * as allIcons from '../../output.json';

interface IconProps {
    name: string,
    width?: string | number,
    height?: string | number,
    color?: string,
    style?: React.CSSProperties,
    onClick?: (event: React.MouseEvent<HTMLOrSVGElement>) => void
}

export const Icon: FC<IconProps> = ({ name, width = 24, height = 24, style, color, onClick }) => {
    const renderPaths = allIcons[name]?.paths?.map((path: string, index: number) => {
        return (<path key={index} d={path}></path>)
    })

    const viewBox = allIcons[name]?.viewBox;

    const handleClick = (e: React.MouseEvent<HTMLOrSVGElement>): void => onClick?.(e);

    return (
        <svg style={{ width, height, ...style }} fill={color || 'currentColor'} viewBox={viewBox} onClick={handleClick}>
            {renderPaths}
        </svg>
    )
}

export const { light } = allIcons; 

